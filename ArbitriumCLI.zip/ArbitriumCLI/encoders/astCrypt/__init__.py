
_encoder_name_ = "Abtract synthax encoder"
_version_ = "1.0.0 beta"
_platforms_ = ["windows", "linux"]