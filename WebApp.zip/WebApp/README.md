[![](https://img.shields.io/badge/vue-2.x-brightgreen.svg)](#) [![](https://img.shields.io/badge/license-Apache%202-blue)](#)



# Arbitrium WebApp

This web interface is still in developpement, but it allows you to easily use the different features of [ArbitriumRAT](https://github.com/BenChaliah/Arbitrium-RAT), the WebApp also have an interactive Terminal, CMD or PowerShell UI.


### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Demo

