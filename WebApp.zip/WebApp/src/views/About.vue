<template>
  <div class="about">
    <router-link to="/">Home</router-link> |
    <router-link to="/about">About</router-link>
    <h1>This is an about page</h1>
  </div>
</template>
